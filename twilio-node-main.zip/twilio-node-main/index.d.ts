import lib from "./lib";
export = lib;
