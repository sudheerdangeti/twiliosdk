import IntelligenceBase from "./IntelligenceBase";

class Intelligence extends IntelligenceBase {}

export = Intelligence;
