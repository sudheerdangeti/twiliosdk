import OauthBase from "./OauthBase";

class Oauth extends OauthBase {}

export = Oauth;
