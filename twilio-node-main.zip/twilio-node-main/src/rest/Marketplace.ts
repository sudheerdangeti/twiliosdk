import MarketplaceBase from "./MarketplaceBase";

class Marketplace extends MarketplaceBase {}

export = Marketplace;
