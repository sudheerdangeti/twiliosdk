import PreviewIamBase from "./PreviewIamBase";

class PreviewIam extends PreviewIamBase {}

export = PreviewIam;
